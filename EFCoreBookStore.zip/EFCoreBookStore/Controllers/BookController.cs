using System.Linq;
using Microsoft.AspNetCore.Mvc;
using EFCoreBookStore.Models;
using System.Collections.Generic;

namespace EFCoreBookStore.Controllers
{
    public class BookController : Controller
    {
        BookStoreDataContext db = new BookStoreDataContext();

        [HttpGet]
        public IActionResult Index()
        {
            IList<BookViewModel> items = new List<BookViewModel>();
            var bookList = db.Books.ToList();

            foreach(Book book in bookList){
                BookViewModel item = new BookViewModel();

                item.ISBN = book.ISBN;
                item.Title = book.Title;
                item.Photo = book.Photo;
                item.PublishDate = book.PublishDate;
                item.Price = book.Price;
                item.Quantity = book.Quantity;
                var category = db.Categories.Where(p=>p.CategoryID.Equals(book.CategoryID)).Single<Category>();
                item.CategoryName = category.Name;

                string authorNameList = string.Empty;
                var booksAuthorsList = db.BooksAuthors.Where(p=>p.ISBN.Equals(book.ISBN));
                foreach(BookAuthor booksAuthors in booksAuthorsList){
                    BookStoreDataContext db2 = new BookStoreDataContext();
                    var author = db2.Authors.Where(p=>p.AuthorID.Equals(booksAuthors.AuthorID)).Single<Author>();
                    authorNameList = authorNameList + author.Name + ", ";
                }
                item.AuthorNames = authorNameList.Substring(0, authorNameList.Length - 2);

                items.Add(item);
            }

            return View(items);
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Categories = db.Categories.ToList();
            ViewBag.Authors = db.Authors.ToList();

            return View();
        }

        [HttpPost]
        public IActionResult Create(Category item)
        {
            if(ModelState.IsValid){
                db.Add(item);
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpGet]
        public IActionResult Edit(int? id)
        {
            var item = db.Categories.SingleOrDefault(p=>p.CategoryID.Equals(id));
            
            return View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit([Bind("CategoryID,Name")] Category item)
        {
            if(ModelState.IsValid){
                db.Update(item);
                db.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return View(item);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            if(ModelState.IsValid)
            {
                var item = db.Categories.Find(id);
                db.Categories.Remove(item);
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View();
        }
    }
}
