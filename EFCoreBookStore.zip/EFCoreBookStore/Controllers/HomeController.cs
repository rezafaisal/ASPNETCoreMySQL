using System.Linq;
using Microsoft.AspNetCore.Mvc;
using EFCoreBookStore.Models;

namespace EFCoreBookStore.Controllers
{
    public class HomeController : Controller
    {

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
    }
}
