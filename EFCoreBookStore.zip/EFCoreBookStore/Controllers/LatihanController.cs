using System.Linq;
using Microsoft.AspNetCore.Mvc;
using EFCoreBookStore.Models;

namespace EFCoreBookStore.Controllers
{
    public class LatihanController : Controller
    {

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Template()
        {
            BookStoreDataContext db = new BookStoreDataContext();
            ViewBag.Authors = db.Authors.ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Template(Category item)
        {
            if (ModelState.IsValid)
            {
            }
            return View();
        }
    }
}